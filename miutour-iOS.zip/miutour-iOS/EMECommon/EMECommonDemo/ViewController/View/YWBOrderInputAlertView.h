//
//  YWBOrderAlertView.h
//  EMECommonLib
//
//  Created by appeme on 14-4-30.
//  Copyright (c) 2014年 上海伊墨科技股份有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "YWBAlertView.h"
@interface YWBOrderInputAlertView : YWBAlertView

@property(nonatomic,strong)UITextField *evOrderNumberTextField;
@property(nonatomic,strong)UITextView *evOrderRemarkTextView;

@end
