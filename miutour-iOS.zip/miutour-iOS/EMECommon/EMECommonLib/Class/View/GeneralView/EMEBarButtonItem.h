//
//  EMEBarButtonItem.h
//  EMECommonLib
//
//  Created by appeme on 14-5-9.
//  Copyright (c) 2014年 上海伊墨科技股份有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EMEBarButtonItem : UIBarButtonItem
@property(nonatomic,assign)BOOL isLeft;
@end
