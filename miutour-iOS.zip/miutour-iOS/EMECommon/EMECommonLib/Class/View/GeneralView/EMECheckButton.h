
#import <UIKit/UIKit.h>

@interface EMECheckButton : UIButton{
 
}

@property (nonatomic,strong) id bindObj;
@property (nonatomic,strong) NSIndexPath *path;

@end
