
@protocol EMEGridViewCellInfoProtocol
@property (nonatomic, assign) NSUInteger xPosition, yPosition;
@property (nonatomic, assign) CGRect frame;
@end
