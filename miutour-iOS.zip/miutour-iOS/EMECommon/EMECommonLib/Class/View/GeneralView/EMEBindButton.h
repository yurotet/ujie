

#import <UIKit/UIKit.h>

@interface EMEBindButton : UIButton{
    id binds;
}
@property(nonatomic,strong)id binds;
@end
