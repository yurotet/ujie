

#import "EMECheckButton.h"

@implementation EMECheckButton

@synthesize bindObj,path;
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

@end
