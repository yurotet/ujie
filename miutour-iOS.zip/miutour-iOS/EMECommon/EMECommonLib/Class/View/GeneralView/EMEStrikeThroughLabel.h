
#import <UIKit/UIKit.h>

@interface EMEStrikeThroughLabel : UILabel{
    BOOL isWithStrikeThrough;
}
@property (nonatomic, assign) BOOL isWithStrikeThrough;
 
@end
