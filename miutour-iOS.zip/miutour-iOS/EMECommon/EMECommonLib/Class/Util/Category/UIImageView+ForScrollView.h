//
//  UIImageView+ForScrollView.h
//  EMEAPP
//
//  Created by appeme on 13-11-13.
//  Copyright (c) 2013年 YXW. All rights reserved.
//

#import <UIKit/UIKit.h>
#define noDisableVerticalScrollTag 836913
#define noDisableHorizontalScrollTag 836914
@interface UIImageView (ForScrollView)

@end
