//
//  UIControl+Selected.h
//  EMECommonLib
//
//  Created by appeme on 3/20/14.
//  Copyright (c) 2014 上海伊墨科技股份有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIControl (Selected)

@end

@interface UITextField(Selected)

@end

@interface UITextView (Selected)
@end
