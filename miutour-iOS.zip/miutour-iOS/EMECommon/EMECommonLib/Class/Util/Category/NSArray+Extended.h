//
//  NSArray+Extended.h
//  EMECommonLib
//
//  Created by ZhuJianyin on 14-3-17.
//  Copyright (c) 2014年 上海伊墨科技股份有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSArray (Extended)

-(id)objectAtIndexWithSafety:(NSUInteger)index;

@end
