
#import <Foundation/Foundation.h>


@interface EMEMacAddress : NSObject {

}
+(NSString *)getMacAddress;
@end
