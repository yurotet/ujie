//
//  Account.m
//  EMECommonLib
//
//  Created by ZhuJianyin on 14-4-23.
//  Copyright (c) 2014年 上海伊墨科技股份有限公司. All rights reserved.
//

#import "Account.h"

@implementation Account

-(id)init
{
    self=[super init];
    if (self) {
        
    }
    return self;
}

@end
