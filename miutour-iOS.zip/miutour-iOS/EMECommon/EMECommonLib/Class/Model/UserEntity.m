//
//  UserEntity.m
//  EMEAPP
//
//  Created by appeme on 13-11-26.
//  Copyright (c) 2013年 YXW. All rights reserved.
//

#import "UserEntity.h"

@implementation UserEntity

@end
