//
//  ProductConsultEntity.m
//  EMECommonLib
//
//  Created by YXW on 14-5-9.
//  Copyright (c) 2014年 上海伊墨科技股份有限公司. All rights reserved.
//

#import "ProductConsultEntity.h"


@implementation ProductConsultEntity

@dynamic createTime;
@dynamic productCode;
@dynamic productId;
@dynamic productLimit;
@dynamic productName;
@dynamic productPrice;
@dynamic productRemain;
@dynamic userId;
@dynamic userName;
@dynamic messageIdArray;

@end
