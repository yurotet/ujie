//
//  CartEntity.m
//  EMECommonLib
//
//  Created by YXW on 14-5-8.
//  Copyright (c) 2014年 上海伊墨科技股份有限公司. All rights reserved.
//

#import "CartEntity.h"


@implementation CartEntity

@dynamic isSelect;
@dynamic productCount;
@dynamic productId;
@dynamic productPrice;
@dynamic remark;
@dynamic shopAddress;
@dynamic shopContactTel;
@dynamic shopId;
@dynamic shopName;
@dynamic shopSort;
@dynamic shopThumb;
@dynamic shopAddrNum;
@dynamic productIcon;
@dynamic productCode;

@end
