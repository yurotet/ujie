//
//  UserSupply.m
//  YWBPurchase
//
//  Created by YXW on 14-4-3.
//  Copyright (c) 2014年 YXW. All rights reserved.
//

#import "UserSupply.h"

@implementation UserSupply

@end
