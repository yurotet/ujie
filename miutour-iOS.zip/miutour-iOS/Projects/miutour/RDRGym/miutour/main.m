//
//  main.m
//  miutour
//
//  Created by Dong on 12/20/14.
//  Copyright (c) 2014 Dong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MTAppDelegate.h"
#import "TestAppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([MTAppDelegate class]));
    }
}


