//
//  MTServiceViewController.h
//  miutour
//
//  Created by Ge on 28/7/15.
//  Copyright (c) 2015 Dong. All rights reserved.
//

#import "BaseViewController.h"

@interface MTServiceViewController : BaseViewController

@end
