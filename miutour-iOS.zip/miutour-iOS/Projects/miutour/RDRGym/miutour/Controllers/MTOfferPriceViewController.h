//
//  MTOfferPriceViewController.h
//  miutour
//
//  Created by Miutour on 15/7/28.
//  Copyright (c) 2015年 Dong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MTTakenOrderViewController.h"

@interface MTOfferPriceViewController :BaseViewController

- (void)loadNewData;



@end
