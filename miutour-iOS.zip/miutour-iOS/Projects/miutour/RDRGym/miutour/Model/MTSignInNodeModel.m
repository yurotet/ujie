//
//  MTSignInNodeModel.m
//  miutour
//
//  Created by Ge on 6/27/15.
//  Copyright (c) 2015 Dong. All rights reserved.
//

#import "MTSignInNodeModel.h"

@implementation MTSignInNodeModel

- (id)init
{
    self = [super init];
    if (self != nil) {
        _beSigned = NO;
    }
    return self;
}



@end
