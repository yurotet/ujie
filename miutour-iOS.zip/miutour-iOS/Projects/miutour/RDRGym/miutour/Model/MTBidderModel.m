//
//  MTBidderModel.m
//  miutour
//
//  Created by Ge on 7/1/15.
//  Copyright (c) 2015 Dong. All rights reserved.
//

#import "MTBidderModel.h"

@implementation MTBidderModel

@end
