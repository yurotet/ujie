//
//  MTActivityModel.m
//  miutour
//
//  Created by Ge on 10/7/15.
//  Copyright (c) 2015 Dong. All rights reserved.
//

#import "MTActivityModel.h"

@implementation MTActivityModel

@end
