//
//  MTCarModel.m
//  miutour
//
//  Created by Ge on 6/30/15.
//  Copyright (c) 2015 Dong. All rights reserved.
//

#import "MTCarModel.h"

@implementation MTCarModel

@end
