//
//  RDR_PickupModel.m
//  miutour
//
//  Created by Dong on 6/6/15.
//  Copyright (c) 2015 Dong. All rights reserved.
//

#import "MTPickupModel.h"

@implementation MTPickupModel

@end
