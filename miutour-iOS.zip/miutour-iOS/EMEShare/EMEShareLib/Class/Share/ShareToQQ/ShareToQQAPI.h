//
//  ShareToQQ.h
//  EMEShare
//
//  Created by ZhuJianyin on 14-3-19.
//  Copyright (c) 2014年 EME. All rights reserved.
//

#import "Share.h"

@interface ShareToQQAPI : Share

-(void)initTencent;

@end
