//
//  ShareToWechatTimelineAPI.h
//  EMEShare
//
//  Created by ZhuJianyin on 14-3-25.
//  Copyright (c) 2014年 EME. All rights reserved.
//

#import "ShareToWechatSessionAPI.h"

@interface ShareToWechatTimelineAPI : ShareToWechatSessionAPI

@end
