//
//  ShareToQzoneAPI.h
//  EMEShare
//
//  Created by ZhuJianyin on 14-3-24.
//  Copyright (c) 2014年 EME. All rights reserved.
//

//#import "Share.h"
#import "ShareToQQAPI.h"

@interface ShareToQzoneAPI : ShareToQQAPI

@end
