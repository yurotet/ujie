//
//  ShareToSinaAPI.h
//  EMEShare
//
//  Created by ZhuJianyin on 14-3-26.
//  Copyright (c) 2014年 EME. All rights reserved.
//

#import "Share.h"
#import "WeiboSDK.h"

@interface ShareToSinaAPI : Share

@end
