//
//  ShareToWechatSessionAPI.h
//  EMEShare
//
//  Created by ZhuJianyin on 14-3-25.
//  Copyright (c) 2014年 EME. All rights reserved.
//

#import "Share.h"

@interface ShareToWechatSessionAPI : Share

@property(nonatomic,assign)enum WXScene scene;

@end
