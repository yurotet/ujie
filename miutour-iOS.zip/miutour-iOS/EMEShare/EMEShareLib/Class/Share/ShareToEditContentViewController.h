//
//  ShareToEditContentViewController.h
//  EMEShare
//
//  Created by ZhuJianyin on 14-3-21.
//  Copyright (c) 2014年 EME. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Share;

@interface ShareToEditContentViewController : UIViewController

@property(nonatomic,strong)Share *share;

@end
