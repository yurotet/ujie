//
//  ShareToSmsAPI.h
//  EMEShare
//
//  Created by ZhuJianyin on 14-3-25.
//  Copyright (c) 2014年 EME. All rights reserved.
//

#import "Share.h"

@interface ShareToSmsAPI : Share

@end
