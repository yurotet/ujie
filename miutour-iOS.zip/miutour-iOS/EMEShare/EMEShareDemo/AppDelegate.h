//
//  AppDelegate.h
//  EMEShareDemo
//
//  Created by appeme on 3/28/14.
//  Copyright (c) 2014 EME. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
